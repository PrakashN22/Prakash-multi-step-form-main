import React from "react";
import { MultiStepForm } from "./components/MultiStepForm";

function App() {
  return (
    <div className="App">
      <MultiStepForm />
    </div>
  );
}

export default App;
